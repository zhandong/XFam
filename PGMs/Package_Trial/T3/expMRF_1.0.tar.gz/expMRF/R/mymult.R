mymult <-
function(pvec){return(rmultinom(1,1,pvec))}
